class User:
    def __init__(self, name, password):
        self.name = name
        self.password = password
        self.balance = 0


    def make_deposit(self, amount):

        self.balance += amount

    def make_withdraw(self, amount):

        self.balance -= amount

    def Greeting(self):
        print(f"Howdy My Name is {self.name}! I have ${self.balance} in my account.")

#Did not work but attempted for a bit
    #def transfer(self, other_user, amount):
        #self.balance - amount
        #other_user + amount



Brody = User("Brody", "12345")
Brynn = User("Brynn", "ABCDE")
Jett = User("Jett", "Password")
Sage = User("Sage", "123ABC")

Brynn.make_deposit(1000)
Brynn.make_deposit(1000)
Brynn.make_deposit(777)
Brynn.make_withdraw(250)
Brynn.Greeting()
Brody.make_deposit(10)
Brody.make_deposit(100)
Brody.make_withdraw(25)
Brody.make_withdraw(40)
Brody.Greeting()
Sage.make_deposit(420)
Sage.make_withdraw(69)
Sage.make_withdraw(69)
Sage.make_withdraw(69)
Sage.Greeting()

#Brody.transfer(Brynn, 100)