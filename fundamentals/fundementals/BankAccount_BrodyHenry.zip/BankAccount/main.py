class BankAccount:
    Users = []
    def __init__(self, interest, balance): 
        self.interest = interest
        self.balance = balance
        BankAccount.Users.append(self)

    def deposit(self, amount):
        self.balance += amount
        return self

    def withdraw(self, amount):
        if(self.balance - amount) >= 0:
            self.balance -= amount
        else: 
            print("Insufficent Funds Withdraw Declined")
        return self

    def display_account_info(self):
        print(f"Your balance is: {self.balance}")
        return self

    def interestrate(self):
        if self.balance > 0:
            self.balance += (self.balance * self.interest)
        return self

#Not sure what went wrong here
    @classmethod
    def printusers(cls):
        for User in cls.Users:
            User.display_account_info()

Brody = BankAccount(.03, 1000)
Brynn = BankAccount(.09, 2000)

Brody.deposit(199).deposit(444).deposit(70).withdraw(188).interestrate().display_account_info()
Brynn.deposit(20).deposit(220).deposit(163).withdraw(84).interestrate().display_account_info()
